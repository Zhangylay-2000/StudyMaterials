-- Docs: https://docs.mage.ai/guides/sql-blocks
SELECT * FROM {{ df_1 }} 