import io
import pandas as pd
import requests
if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data_from_api(*args, **kwargs):
    """
    Template for loading data from API
    import pandas as pd


    """
    import pandas as pd


    #url = 'https://github.com/Zhangylay-2000/de-zoomcamp/blob/b4d18e83c4b6a20e98235a7c0fa4228f8110a8f6/Netflix%20Userbase.csv'
    #response = requests.get(url)
   

    url = 'https://github.com/Zhangylay-2000/de-zoomcamp/blob/b4d18e83c4b6a20e98235a7c0fa4228f8110a8f6/Netflix%20Userbase.csv?raw=true'
    response = requests.get(url)
    df = pd.read_csv(url, index_col=0)

    #print(df.head(5))

    return pd.read_csv(io.StringIO(response.text), sep=',')

